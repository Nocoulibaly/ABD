// templates/src/App.jsx

import { Header, Footer } from './components/layout.js';
import AvailabilitySearch from './components/AvailabilitySearch.js';

const App = () => {
  return (
    <React.Fragment>
      <Header />
      <main className="pt-20">
        <AvailabilitySearch />
      </main>
      <Footer />
    </React.Fragment>
  );
};

const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(<App />);