 // Store rooms data
 let rooms = [];
 // Stockage de l'historique (simulation d'une base de données)
 const roomHistory = {};

 // Function to generate room card HTML
 function generateRoomCard(room) {
     const statusClasses = {
         'Disponible': 'status-available',
         'Occupée': 'status-occupied',
         'Maintenance': 'status-maintenance'
     };

     return `
         <div class="col-md-4 mb-4" data-room-id="${room.id}">
             <div class="card">
                 <div class="card-body">
                     <div class="d-flex justify-content-between align-items-center mb-3">
                         <h5 class="card-title">Chambre ${room.number}</h5>
                         <span class="status-badge ${statusClasses[room.status]}">${room.status}</span>
                     </div>
                     <div class="room-info">
                         <p class="room-type mb-2">Type: ${room.type}</p>
                         <p class="room-capacity mb-2">
                             <i class="fas fa-user"></i> Capacité: ${room.capacity} personnes
                         </p>
                         <p class="room-price mb-2">
                         <i class="fas fa-money-bill-wave"></i> Prix: ${room.price}Fcfa /nuit
                         </p>
                         <p class="room-description">
                             ${room.description}
                         </p>
                     </div>
                     <div class="d-flex justify-content-between mt-3">
                         <button class="btn btn-outline-primary btn-sm" onclick="editRoom(${room.id})">
                             <i class="fas fa-edit"></i> Modifier
                         </button>
                         <button class="btn btn-outline-info btn-sm" onclick="showHistory(${room.id})">
                             <i class="fas fa-history"></i> Historique
                         </button>
                     </div>
                 </div>
             </div>
         </div>
     `;
 }

 // Function to refresh rooms display
 function refreshRoomsDisplay() {
     const roomsGrid = document.getElementById('roomsGrid');
     roomsGrid.innerHTML = rooms.map(room => generateRoomCard(room)).join('');
 }

         // Fonction pour créer une carte de chambre (même fonction qu'avant, mais avec modification du bouton)
         function createRoomCard(roomData) {
     const roomsContainer = document.querySelector('#roomsGrid');
     
     const card = document.createElement('div');
     card.className = 'col-md-4 mb-4';
     card.setAttribute('data-room-number', roomData.number);
     
     const statusClass = {
         'Disponible': 'status-available',
         'Occupée': 'status-occupied',
         'Maintenance': 'status-maintenance'
     }[roomData.status];

     card.innerHTML = `
         <div class="card">
             <div class="card-body">
                 <div class="d-flex justify-content-between align-items-center mb-3">
                     <h5 class="card-title">Chambre ${roomData.number}</h5>
                     <span class="status-badge ${statusClass}">${roomData.status}</span>
                 </div>
                 <div class="room-info">
                     <p class="room-type mb-2">Type: ${roomData.type}</p>
                     <p class="room-capacity mb-2">
                         <i class="fas fa-user"></i> Capacité: ${roomData.capacity} personnes
                     </p>
                     <p class="room-price mb-2">
                     <i class="fas fa-money-bill-wave"></i> Prix: ${roomData.price}Fcfa /nuit
                     </p>
                     <p class="room-description">
                         ${roomData.description}
                     </p>
                 </div>
                 <div class="d-flex justify-content-between mt-3">
                     <button class="btn btn-outline-primary btn-sm edit-room" data-bs-toggle="modal" data-bs-target="#editRoomModal" onclick="openEditModal(this)">
                         <i class="fas fa-edit"></i> Modifier
                     </button>
                     <button class="btn btn-outline-info btn-sm">
                         <i class="fas fa-history"></i> Historique
                     </button>
                 </div>
             </div>
         </div>
     `;
      // Modifier le bouton d'historique
      const historyButton = card.querySelector('.btn-outline-info');
     historyButton.onclick = () => showHistory(roomData.number);
     roomsContainer.appendChild(card);
 }


 // Gestionnaire de soumission du formulaire
 document.getElementById('addRoomForm').addEventListener('submit', function(e) {
     e.preventDefault();

     const roomData = {
         number: document.getElementById('roomNumber').value,
         type: document.getElementById('roomType').value,
         capacity: document.getElementById('roomCapacity').value,
         price: document.getElementById('roomPrice').value,
         description: document.getElementById('roomDescription').value,
         status: document.getElementById('roomStatus').value
     };

     // Créer et ajouter la nouvelle carte de chambre
     createRoomCard(roomData);

     // Fermer le modal
     const modal = bootstrap.Modal.getInstance(document.getElementById('addRoomModal'));
     modal.hide();

     // Réinitialiser le formulaire
     this.reset();
 });

  // Fonction pour ouvrir le modal de modification avec les données de la chambre
  function openEditModal(button) {
     const card = button.closest('.col-md-4');
     const roomNumber = card.getAttribute('data-room-number');
     
     // Récupérer les données actuelles de la chambre
     const roomType = card.querySelector('.room-type').textContent.split(': ')[1];
     const roomCapacity = card.querySelector('.room-capacity').textContent.match(/\d+/)[0];
     const roomPrice = card.querySelector('.room-price').textContent.match(/\d+/)[0];
     const roomDescription = card.querySelector('.room-description').textContent.trim();
     const roomStatus = card.querySelector('.status-badge').textContent;

     // Remplir le formulaire de modification
     document.getElementById('editRoomNumber').value = roomNumber;
     document.getElementById('editRoomType').value = roomType;
     document.getElementById('editRoomCapacity').value = roomCapacity;
     document.getElementById('editRoomPrice').value = roomPrice;
     document.getElementById('editRoomDescription').value = roomDescription;
     document.getElementById('editRoomStatus').value = roomStatus;
 }

 // Gestionnaire de soumission du formulaire de modification
 document.getElementById('editRoomForm').addEventListener('submit', function(e) {
     e.preventDefault();

     const roomNumber = document.getElementById('editRoomNumber').value;
     const roomData = {
         number: roomNumber,
         type: document.getElementById('editRoomType').value,
         capacity: document.getElementById('editRoomCapacity').value,
         price: document.getElementById('editRoomPrice').value,
         description: document.getElementById('editRoomDescription').value,
         status: document.getElementById('editRoomStatus').value
     };

     // Supprimer l'ancienne carte
     const oldCard = document.querySelector(`[data-room-number="${roomNumber}"]`);
     if (oldCard) {
         oldCard.remove();
     }

     // Créer la nouvelle carte avec les données modifiées
     createRoomCard(roomData);

     // Fermer le modal
     const modal = bootstrap.Modal.getInstance(document.getElementById('editRoomModal'));
     modal.hide();
 });

// Fonction pour afficher l'historique
function showHistory(roomNumber) {
     document.getElementById('historyRoomNumber').textContent = roomNumber;
     document.getElementById('historyEntryRoomNumber').value = roomNumber;
     
     const historyTableBody = document.getElementById('historyTableBody');
     historyTableBody.innerHTML = '';

     if (!roomHistory[roomNumber] || roomHistory[roomNumber].length === 0) {
         historyTableBody.innerHTML = `
             <tr>
                 <td colspan="5" class="no-history">Aucun historique disponible pour cette chambre</td>
             </tr>
         `;
     } else {
         roomHistory[roomNumber].forEach(entry => {
             const row = document.createElement('tr');
             row.innerHTML = `
                 <td>${new Date(entry.date).toLocaleDateString()}</td>
                 <td>${entry.status}</td>
                 <td>${entry.client || '-'}</td>
                 <td>${entry.price ? entry.price + 'Fcfa' : '-'}</td>
                 <td>${entry.notes || '-'}</td>
             `;
             historyTableBody.appendChild(row);
         });
     }

     const historyModal = new bootstrap.Modal(document.getElementById('historyModal'));
     historyModal.show();
 }

 // Gestionnaire pour le bouton "Ajouter une entrée"
 document.getElementById('addHistoryEntry').addEventListener('click', function() {
     const historyModal = bootstrap.Modal.getInstance(document.getElementById('historyModal'));
     historyModal.hide();
     
     const addEntryModal = new bootstrap.Modal(document.getElementById('addHistoryEntryModal'));
     addEntryModal.show();
 });

 // Gestionnaire pour le formulaire d'ajout d'entrée d'historique
 document.getElementById('addHistoryEntryForm').addEventListener('submit', function(e) {
     e.preventDefault();

     const roomNumber = document.getElementById('historyEntryRoomNumber').value;
     const newEntry = {
         date: document.getElementById('historyEntryDate').value,
         status: document.getElementById('historyEntryStatus').value,
         client: document.getElementById('historyEntryClient').value,
         price: document.getElementById('historyEntryPrice').value,
         notes: document.getElementById('historyEntryNotes').value
     };

     if (!roomHistory[roomNumber]) {
         roomHistory[roomNumber] = [];
     }

     roomHistory[roomNumber].push(newEntry);
     roomHistory[roomNumber].sort((a, b) => new Date(b.date) - new Date(a.date));

     const addEntryModal = bootstrap.Modal.getInstance(document.getElementById('addHistoryEntryModal'));
     addEntryModal.hide();

     showHistory(roomNumber);
 });

 // Réinitialiser le formulaire d'ajout d'entrée quand le modal est fermé
 document.getElementById('addHistoryEntryModal').addEventListener('hidden.bs.modal', function() {
     document.getElementById('addHistoryEntryForm').reset();
 });
 // Filter functionality
 function applyFilters() {
     const statusFilter = document.querySelector('select:nth-of-type(1)').value;
     const typeFilter = document.querySelector('select:nth-of-type(2)').value;
     const floorFilter = document.querySelector('select:nth-of-type(3)').value;

     const filteredRooms = rooms.filter(room => {
         const statusMatch = statusFilter === 'Tous' || room.status === statusFilter;
         const typeMatch = typeFilter === 'Tous' || room.type === typeFilter;
         // Add floor filtering logic if needed
         return statusMatch && typeMatch;
     });

     const roomsGrid = document.getElementById('roomsGrid');
     roomsGrid.innerHTML = filteredRooms.map(room => generateRoomCard(room)).join('');
 }

 // Add event listeners to filter selects
 document.querySelectorAll('.filters select').forEach(select => {
     select.addEventListener('change', applyFilters);
 });

 