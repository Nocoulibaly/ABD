// État global
let reservations = [
    {
        id: "12345",
        status: "confirmed",
        client: "Jean Dupont",
        room: "201",
        roomType: "Deluxe",
        checkIn: "2023-07-20",
        checkOut: "2023-07-25",
        amount: 850000,
        adults: 2,
        children: 0,
        specialRequests: ""
    }
];

// Fonctions utilitaires
function formatDate(dateStr) {
    return new Date(dateStr).toLocaleDateString('fr-FR');
}

function calculateAmount(reservation) {
    const baseRates = {
        "Standard": 100,
        "Deluxe": 150,
        "Suite": 250
    };
    const nights = Math.ceil(
        (new Date(reservation.checkOut) - new Date(reservation.checkIn)) / (1000 * 60 * 60 * 24)
    );
    return baseRates[reservation.roomType] * nights;
}

// Gestion de l'affichage
function renderReservations(reservationsToShow) {
    const grid = document.getElementById('reservationsGrid');
    grid.innerHTML = reservationsToShow.map(reservation => `
        <div class="reservation-card">
            <div class="reservation-header">
                <h3>Réservation #${reservation.id}</h3>
                <span class="status-badge status-${reservation.status}">
                    ${reservation.status === "confirmed" ? "Confirmé" :
                      reservation.status === "pending" ? "En attente" : "Annulé"}
                </span>
            </div>
            <div>
                <p><strong>Client:</strong> ${reservation.client}</p>
                <p><strong>Chambre:</strong> ${reservation.room} - ${reservation.roomType}</p>
                <p><strong>Arrivée:</strong> ${formatDate(reservation.checkIn)}</p>
                <p><strong>Départ:</strong> ${formatDate(reservation.checkOut)}</p>
                <p><strong>Montant:</strong> ${reservation.amount}Fcfa</p>
            </div>
        </div>
    `).join('');
}

// Filtrage
function applyFilters() {
    const checkIn = document.getElementById('filterCheckIn').value;
    const checkOut = document.getElementById('filterCheckOut').value;
    const status = document.getElementById('filterStatus').value;
    const roomType = document.getElementById('filterRoomType').value;

    const filtered = reservations.filter(reservation => {
        if (checkIn && new Date(reservation.checkIn) < new Date(checkIn)) return false;
        if (checkOut && new Date(reservation.checkOut) > new Date(checkOut)) return false;
        if (status !== "all" && reservation.status !== status) return false;
        if (roomType !== "all" && reservation.roomType !== roomType) return false;
        return true;
    });

    renderReservations(filtered);
}

// Gestion du modal
function openModal() {
    document.getElementById('reservationModal').classList.add('active');
}

function closeModal() {
    document.getElementById('reservationModal').classList.remove('active');
    document.getElementById('reservationForm').reset();
}

// Gestion des réservations
function handleSubmitReservation(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const newReservation = {
        id: Math.random().toString(36).substr(2, 9),
        status: "pending",
        room: String(Math.floor(Math.random() * 500 + 100)),
        ...Object.fromEntries(formData)
    };
    
    newReservation.amount = calculateAmount(newReservation);
    
    reservations.push(newReservation);
    closeModal();
    applyFilters();
}

// Initialisation
document.addEventListener('DOMContentLoaded', () => {
    renderReservations(reservations);
});