// src/App.js
import React from 'react';
import UserProvider from './providers/UserProvider';
import DarkModeProvider from './providers/DarkModeProvider';
import Header from './components/Header';
import Carousel from './components/Carousel';
import Features from './components/Features';
import Rooms from './components/Rooms';
import BookingWidget from './components/BookingWidget/BookingWidget';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';

const App = () => (
  <div>
    <UserProvider>
      <Header />
      <DarkModeProvider>
        <Carousel />
        <Features />
        <Rooms />
        <BookingWidget />
        <Testimonials />
        <Footer />
      </DarkModeProvider>
    </UserProvider>
  </div>
);

export default App;