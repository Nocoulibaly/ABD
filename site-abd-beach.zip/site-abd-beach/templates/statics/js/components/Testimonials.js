// js/Testimonials.js
import React from 'react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "Sophie Martin",
      image: "/testimonial1.jpg",
      text: "Un séjour inoubliable ! Le service était impeccable et la chambre parfaite.",
      rating: 5
    },
    {
      name: "Jean Dupont",
      image: "/testimonial2.jpg",
      text: "Le restaurant est excellent et le personnel très attentionné.",
      rating: 5
    },
    {
      name: "Marie Lambert",
      image: "/testimonial3.jpg",
      text: "Superbe hôtel avec une vue magnifique. Je reviendrai !",
      rating: 4
    }
  ];

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-semibold text-center mb-12">Avis Clients</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h3 className="font-semibold">{testimonial.name}</h3>
                  <div className="flex text-yellow-400">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <span key={i}>⭐</span>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600">{testimonial.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;