// js/BookingWidget/hooks/useBookingForm.js
import { useState } from 'react';

export const useBookingForm = () => {
  const [formData, setFormData] = useState({
    checkIn: '',
    checkOut: '',
    guests: 1
  });

  const [validation, setValidation] = useState({
    checkIn: true,
    checkOut: true,
    guests: true
  });

  const validateDates = () => {
    const today = new Date();
    const checkInDate = new Date(formData.checkIn);
    const checkOutDate = new Date(formData.checkOut);
    
    const isCheckInValid = checkInDate >= today;
    const isCheckOutValid = checkOutDate > checkInDate;

    setValidation({
      ...validation,
      checkIn: isCheckInValid,
      checkOut: isCheckOutValid
    });

    return isCheckInValid && isCheckOutValid;
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return {
    formData,
    validation,
    handleInputChange,
    validateDates
  };
};