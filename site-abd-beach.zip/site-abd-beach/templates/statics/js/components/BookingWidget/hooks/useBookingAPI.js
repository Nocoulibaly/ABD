// js/BookingWidget/hooks/useBookingAPI.js
import { useState } from 'react';

export const useBookingAPI = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const checkAvailability = async (bookingData) => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/availability', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          check_in_date: bookingData.checkIn,
          check_out_date: bookingData.checkOut,
          num_guests: bookingData.guests
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Erreur lors de la vérification de disponibilité');
      }

      return {
        isAvailable: data.is_available,
        rooms: data.rooms
      };

    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    error,
    checkAvailability
  };
};