// auth/session.go
package authentification

import (
	"log"
	"net/http"
)

// Supprimez ou commentez l'ancienne implémentation de store
// var store *sessions.CookieStore

func InitSession(secretKey []byte) {
	// Initialisez le store en mémoire
	InitMemorySession()
}

// Remplacez les anciennes méthodes par des appels au nouveau memory store
func SetSession(w http.ResponseWriter, r *http.Request, userID int) error {
	store := GetMemoryStore()
	_, err := store.SetMemorySession(w, r, userID)
	return err
}

func GetSession(r *http.Request) (int, error) {
	store := GetMemoryStore()
	userID, err := store.GetMemorySession(r)
	if err != nil {
		log.Printf("GetSession: Failed to retrieve session: %v\n", err)
		return 0, err
	}
	log.Printf("GetSession: Session valid for user ID: %d\n", userID)
	return userID, nil
}

func ClearSession(w http.ResponseWriter, r *http.Request) error {
	store := GetMemoryStore()
	return store.ClearMemorySession(w, r)
}

func IsSessionValid(r *http.Request) bool {
	store := GetMemoryStore()
	// Récupérer le token de session depuis le cookie
	cookie, err := r.Cookie("session-token")
	if err != nil {
		log.Println("IsSessionValid: No session token in cookies")
		return false
	}
	log.Printf("IsSessionValid: Received session token: %s\n", cookie.Value)

	// Vérifier si la session est valide en mémoire
	isValid := store.IsMemorySessionValid(r)
	if !isValid {
		log.Printf("IsSessionValid: Session token %s is invalid or expired\n", cookie.Value)
	} else {
		log.Printf("IsSessionValid: Session token %s is valid\n", cookie.Value)
	}

	return isValid
}
