// authentification/non_persistent_session.go
package authentification

import (
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"
)

var (
	// Store global pour les sessions en mémoire
	memoryStore *MemorySessionStore
)

// MemorySession représente une session en mémoire
type MemorySession struct {
	UserID    int
	CreatedAt int64
	ExpiresAt int64
}

// MemorySessionStore stocke les sessions en mémoire
type MemorySessionStore struct {
	sessions     map[string]*MemorySession
	sessionMutex sync.RWMutex
}

// InitMemorySession initialise le store de sessions en mémoire
func InitMemorySession() {
	memoryStore = &MemorySessionStore{
		sessions: make(map[string]*MemorySession),
	}
	go memoryStore.startCleanupTimer()
}

// GetMemoryStore retourne le store de sessions en mémoire
func GetMemoryStore() *MemorySessionStore {
	if memoryStore == nil {
		InitMemorySession()
	}
	return memoryStore
}

// SetMemorySession crée ou met à jour une session en mémoire
func (ms *MemorySessionStore) SetMemorySession(w http.ResponseWriter, r *http.Request, userID int) (string, error) {
	ms.sessionMutex.Lock()
	defer ms.sessionMutex.Unlock()

	// Générer un token de session unique
	sessionToken, err := generateSessionToken()
	if err != nil {
		log.Printf("Error generating session token: %v", err)
		return "", err
	}
	log.Printf("Cookie created: %s\n", sessionToken)

	// Créer la session en mémoire
	session := &MemorySession{
		UserID:    userID,
		CreatedAt: time.Now().Unix(),
		ExpiresAt: time.Now().Add(24 * time.Hour).Unix(), // 1 heures
	}

	// Stocker la session
	ms.sessions[sessionToken] = session
	log.Printf("Session created: token=%s, userID=%d\n", sessionToken, userID)

	// Définir le cookie de session
	http.SetCookie(w, &http.Cookie{
		Name:     "session-token",
		Value:    sessionToken,
		Path:     "/",
		HttpOnly: true,
		Secure:   false, // À ajuster selon votre configuration HTTPS
		MaxAge:   3600 * 24,  // 1 heures
		Domain:   "localhost",
		SameSite: http.SameSiteLaxMode,
	})
	log.Printf("Cookie details - Name: %s, Value: %s, Path: %s, SameSite: %v", 
    "session-token", sessionToken, "/", http.SameSiteLaxMode)
	fmt.Println("cookie")

	return sessionToken, nil
}

// GetMemorySession récupère l'ID utilisateur d'une session en mémoire
func (ms *MemorySessionStore) GetMemorySession(r *http.Request) (int, error) {
	ms.sessionMutex.RLock()
	defer ms.sessionMutex.RUnlock()

	// Récupérer le token de session depuis le cookie
	cookie, err := r.Cookie("session-token")
	if err != nil {
		log.Println("GetMemorySession: No session token in cookies")
		return 0, errors.New("session token not found")
	}

	log.Printf("GetMemorySession: Cookie received - %s\n", cookie.Value)

	// Vérifier si la session existe
	session, exists := ms.sessions[cookie.Value]
	if !exists {
		log.Printf("GetMemorySession: Session token %s not found", cookie.Value)
		return 0, errors.New("session invalide")
	}

	// Vérifier l'expiration
	if time.Now().Unix() > session.ExpiresAt {
		log.Printf("GetMemorySession: Session token %s expired", cookie.Value)
		return 0, errors.New("session expirée")
	}

	log.Printf("GetMemorySession: Session token %s is valid for user ID %d\n", cookie.Value, session.UserID)
	return session.UserID, nil
}

// ClearMemorySession supprime une session en mémoire
func (ms *MemorySessionStore) ClearMemorySession(w http.ResponseWriter, r *http.Request) error {
	ms.sessionMutex.Lock()
	defer ms.sessionMutex.Unlock()

	// Récupérer le token de session
	cookie, err := r.Cookie("session-token")
	if err != nil {
		return nil // Pas de session à supprimer
	}

	// Supprimer la session du store
	delete(ms.sessions, cookie.Value)

	// Supprimer le cookie
	http.SetCookie(w, &http.Cookie{
		Name:     "session-token",
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
		Secure:   false,
		SameSite: http.SameSiteLaxMode, // Changé de StrictMode à LaxMode
	})

	return nil
}

// IsMemorySessionValid vérifie si une session en mémoire est valide
func (ms *MemorySessionStore) IsMemorySessionValid(r *http.Request) bool {
	ms.sessionMutex.RLock()
	defer ms.sessionMutex.RUnlock()

	// Récupérer le token de session
	cookie, err := r.Cookie("session-token")
	if err != nil {
		log.Println("IsMemorySessionValid: No session token in cookies")
		return false
	}

	log.Printf("Checking session for token: %s", cookie.Value)

	// Vérifier si la session existe
	session, exists := ms.sessions[cookie.Value]
	if !exists {
		log.Printf("IsMemorySessionValid: Session token %s not found", cookie.Value)
		return false
	}

	// Vérifier l'expiration
	if time.Now().Unix() > session.ExpiresAt {
		log.Printf("IsMemorySessionValid: Session token %s expired", cookie.Value)
		return false
	}

	log.Printf("IsMemorySessionValid: Session token %s is valid", cookie.Value)
	return true
}

// startCleanupTimer nettoie périodiquement les sessions expirées
func (ms *MemorySessionStore) startCleanupTimer() {
	ticker := time.NewTicker(1 * time.Hour)
	for range ticker.C {
		ms.cleanExpiredSessions()
	}
}

// cleanExpiredSessions supprime les sessions expirées
func (ms *MemorySessionStore) cleanExpiredSessions() {
	ms.sessionMutex.Lock()
	defer ms.sessionMutex.Unlock()

	now := time.Now().Unix()
	for token, session := range ms.sessions {
		if now > session.ExpiresAt {
			delete(ms.sessions, token)
		}
	}

	log.Printf("Session cleanup: Removed expired sessions. Total active sessions: %d", len(ms.sessions))
}

// Générer un token de session unique (à remplacer par une méthode plus sécurisée en production)
func generateSessionToken() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", fmt.Errorf("failed to generate random bytes: %w", err)
	}
	timestamp := time.Now().UnixNano()
	return fmt.Sprintf("%d-%s", timestamp, base64.URLEncoding.EncodeToString(b)), nil
}
