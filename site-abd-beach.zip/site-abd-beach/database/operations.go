// database/operations.go
package database

import (
	"context"
	"database/sql"
	"site-abd-beach/models"
	"time"
)

type ReservationRepository struct {
	db *sql.DB
}

func NewReservationRepository(db *sql.DB) *ReservationRepository {
	return &ReservationRepository{db: db}
}

func (r *ReservationRepository) GetAll() ([]*models.Reservation, error) {
	rows, err := r.db.QueryContext(context.Background(), "SELECT id, User_id, room_id, check_in_date, check_out_date, number_of_guests, total_price, status, payment_status, special_requests, created_at, updated_at FROM reservations")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var reservations []*models.Reservation
	for rows.Next() {
		var reservation models.Reservation
		err := rows.Scan(&reservation.ID, &reservation.UserID, &reservation.RoomID, &reservation.CheckInDate, &reservation.CheckOutDate, &reservation.NumberOfGuests, &reservation.TotalPrice, &reservation.Status, &reservation.PaymentStatus, &reservation.SpecialRequests, &reservation.CreatedAt, &reservation.UpdatedAt)
		if err != nil {
			return nil, err
		}
		reservations = append(reservations, &reservation)
	}

	return reservations, nil
}

func (r *ReservationRepository) Update(reservation *models.Reservation) error {
	_, err := r.db.ExecContext(context.Background(), "UPDATE reservations SET User_id = ?, room_id = ?, check_in_date = ?, check_out_date = ?, number_of_guests = ?, total_price = ?, status = ?, payment_status = ?, special_requests = ? WHERE id = ?",
		reservation.UserID, reservation.RoomID, reservation.CheckInDate, reservation.CheckOutDate, reservation.NumberOfGuests, reservation.TotalPrice, reservation.Status, reservation.PaymentStatus, reservation.SpecialRequests, reservation.ID)
	return err
}

func (r *ReservationRepository) Delete(id string) error {
	_, err := r.db.ExecContext(context.Background(), "DELETE FROM reservations WHERE id = ?", id)
	return err
}

func (r *ReservationRepository) Create(reservation *models.Reservation) error {
	result, err := r.db.ExecContext(context.Background(), "INSERT INTO reservations (User_id, room_id, check_in_date, check_out_date, number_of_guests, total_price, status, payment_status, special_requests) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
		reservation.UserID, reservation.RoomID, reservation.CheckInDate, reservation.CheckOutDate, reservation.NumberOfGuests, reservation.TotalPrice, reservation.Status, reservation.PaymentStatus, reservation.SpecialRequests)
	if err != nil {
		return err
	}

	id, err := result.LastInsertId()
	if err != nil {
		return err
	}

	reservation.ID = int(id)
	return nil
}

func (r *ReservationRepository) CheckAvailability(roomID int, checkIn, checkOut time.Time) (bool, error) {
	query := `
        SELECT COUNT(*) FROM reservations
        WHERE room_id = ?
        AND status != 'cancelled'
        AND (
            (check_in_date <= ? AND check_out_date >= ?)
            OR (check_in_date <= ? AND check_out_date >= ?)
            OR (check_in_date >= ? AND check_out_date <= ?)
        )
    `
	var count int
	err := r.db.QueryRowContext(context.Background(), query, roomID, checkOut, checkIn, checkIn, checkOut, checkIn, checkOut).Scan(&count)
	if err != nil {
		return false, err
	}
	return count == 0, nil
}

type EventQuoteRepository struct {
	db *sql.DB
}

func NewEventQuoteRepository(db *sql.DB) *EventQuoteRepository {
	return &EventQuoteRepository{db: db}
}

func (r *EventQuoteRepository) GetAll() ([]*models.EventQuote, error) {
	rows, err := r.db.QueryContext(context.Background(), `
        SELECT
            eq.*, c.firstname, c.lastname, c.email, et.name AS event_type_name,
            es.name AS event_space_name
        FROM event_quotes eq
        JOIN Users c ON eq.User_id = c.id
        JOIN event_types et ON eq.event_type_id = et.id
        JOIN event_spaces es ON eq.event_space_id = es.id
    `)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var quotes []*models.EventQuote
	for rows.Next() {
		var eq models.EventQuote
		var User models.User
		var eventType models.EventType
		var eventSpace models.EventSpace
		err := rows.Scan(
			&eq.ID, &eq.UserID, &eq.EventTypeID, &eq.EventSpaceID, &eq.ExpectedGuests,
			&eq.EventDate, &eq.StartTime, &eq.EndTime, &eq.Description, &eq.SpecialRequirements,
			&eq.BudgetRange, &eq.Status, &eq.CreatedAt, &eq.UpdatedAt,
			&User.FirstName, &User.LastName, &User.Email,
			&eventType.Name, &eventSpace.Name,
		)
		if err != nil {
			return nil, err
		}
		eq.User = &User
		eq.EventType = &eventType
		eq.EventSpace = &eventSpace
		quotes = append(quotes, &eq)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return quotes, nil
}

func (r *EventQuoteRepository) Update(quote *models.EventQuote) error {
	_, err := r.db.ExecContext(context.Background(), `
        UPDATE event_quotes
        SET User_id = ?, event_type_id = ?, event_space_id = ?, expected_guests = ?,
            event_date = ?, start_time = ?, end_time = ?, description = ?, special_requirements = ?,
            budget_range = ?, status = ?
        WHERE id = ?
    `, quote.UserID, quote.EventTypeID, quote.EventSpaceID, quote.ExpectedGuests,
		quote.EventDate, quote.StartTime, quote.EndTime, quote.Description, quote.SpecialRequirements,
		quote.BudgetRange, quote.Status, quote.ID)
	return err
}

func (r *EventQuoteRepository) Delete(id string) error {
	_, err := r.db.ExecContext(context.Background(), "DELETE FROM event_quotes WHERE id = ?", id)
	return err
}

func (r *EventQuoteRepository) Create(quote *models.EventQuote) error {
	result, err := r.db.ExecContext(context.Background(), `
        INSERT INTO event_quotes (
            User_id, event_type_id, event_space_id, expected_guests,
            event_date, start_time, end_time, description, special_requirements,
            budget_range, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, quote.UserID, quote.EventTypeID, quote.EventSpaceID, quote.ExpectedGuests,
		quote.EventDate, quote.StartTime, quote.EndTime, quote.Description, quote.SpecialRequirements,
		quote.BudgetRange, quote.Status)
	if err != nil {
		return err
	}

	id, err := result.LastInsertId()
	if err != nil {
		return err
	}

	quote.ID = int(id)
	return nil
}

func (r *EventQuoteRepository) GetByUserID(UserID int) ([]*models.EventQuote, error) {
	rows, err := r.db.QueryContext(context.Background(), `
        SELECT
            eq.*, c.firstname, c.lastname, c.email, et.name AS event_type_name,
            es.name AS event_space_name
        FROM event_quotes eq
        JOIN Users c ON eq.User_id = c.id
        JOIN event_types et ON eq.event_type_id = et.id
        JOIN event_spaces es ON eq.event_space_id = es.id
        WHERE eq.User_id = ?
    `, UserID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var quotes []*models.EventQuote
	for rows.Next() {
		var eq models.EventQuote
		var User models.User
		var eventType models.EventType
		var eventSpace models.EventSpace
		err := rows.Scan(
			&eq.ID, &eq.UserID, &eq.EventTypeID, &eq.EventSpaceID, &eq.ExpectedGuests,
			&eq.EventDate, &eq.StartTime, &eq.EndTime, &eq.Description, &eq.SpecialRequirements,
			&eq.BudgetRange, &eq.Status, &eq.CreatedAt, &eq.UpdatedAt,
			&User.FirstName, &User.LastName, &User.Email,
			&eventType.Name, &eventSpace.Name,
		)
		if err != nil {
			return nil, err
		}
		eq.User = &User
		eq.EventType = &eventType
		eq.EventSpace = &eventSpace
		quotes = append(quotes, &eq)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return quotes, nil
}
