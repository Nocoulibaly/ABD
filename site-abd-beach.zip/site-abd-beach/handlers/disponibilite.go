package handlers

import (
	"encoding/json"
	"log"
	"net/http"
	"site-abd-beach/database"
	"site-abd-beach/models"
	"time"
)

type AvailabilityResponse struct {
	Available bool             `json:"is_available"`
	Rooms     []models.RoomType `json:"rooms"`
}

type AvailabilityRequest struct {
	CheckInDate  string `json:"check_in_date"`
	CheckOutDate string `json:"check_out_date"`
	NumGuests    string `json:"num_guests"`
}

func SearchAvailability(w http.ResponseWriter, r *http.Request) {
    var request AvailabilityRequest
    err := json.NewDecoder(r.Body).Decode(&request)
    if err != nil {
        http.Error(w, "Invalid request payload", http.StatusBadRequest)
        return
    }

    // Parse les dates d'arrivée et de départ
    checkIn, err1 := time.Parse("2006-01-02", request.CheckInDate)
    checkOut, err2 := time.Parse("2006-01-02", request.CheckOutDate)
    if err1 != nil || err2 != nil || checkOut.Before(checkIn) {
        http.Error(w, "Invalid dates", http.StatusBadRequest)
        return
    }

    // Requête SQL pour sélectionner les chambres disponibles avec le nom et le prix du type de chambre
    query := `
    SELECT 
        id,   
        status, 
        description,
        name AS room_type_name,
        price_per_night
    FROM room_types
`

    db := database.GetDB()
    if db == nil {
        http.Error(w, "Database connection error", http.StatusInternalServerError)
        return
    }

    rows, err := db.Query(query, checkOut, checkIn)
    if err != nil {
        log.Printf("Query error: %v", err)
        http.Error(w, "Error retrieving available rooms", http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var availableRooms []models.RoomType
    for rows.Next() {
        var room models.RoomType
        if err := rows.Scan(&room.ID, &room.Status, &room.Description, &room.Name, &room.PricePerNight); err != nil {
            log.Printf("Scan error: %v", err)
            continue
        }
        availableRooms = append(availableRooms, room)
    }

    response := AvailabilityResponse{
        Available: len(availableRooms) > 0,
        Rooms:     availableRooms,
    }
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(response)
}
