// handlers/profil.go
package handlers

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"site-abd-beach/authentification"
	"site-abd-beach/database"
	"site-abd-beach/models" // Ajustez l'import selon votre structure
	"strconv"
	"strings"
	"text/template"
	"time"
)

// UserProfile struct to hold user information
type UserProfile struct {
	ID           int    `json:"id"`
	FirstName    string `json:"first_name"`
	LastName     string `json:"last_name"`
	Email        string `json:"email"`
	PhoneNumber  string `json:"phone_number"`
	Address      string `json:"address"`
	City         string `json:"city"`
	Country      string `json:"country"`
	Reservations []models.Reservation
}

// Structure pour la réponse d'erreur API
type APIError struct {
	Error string `json:"error"`
}

// Structure pour la mise à jour de réservation
type UpdateReservationRequest struct {
	ReservationID  int    `json:"reservation_id"`
	CheckInDate    string `json:"check_in_date"`
	CheckOutDate   string `json:"check_out_date"`
	NumberOfGuests int    `json:"number_of_guests"`
	Status         string `json:"status"`
	RoomID         int    `json:"room_id"`
}

type contextKey string

const (
	userIDKey contextKey = "userID"
	//reservationKey contextKey = "reservation"
)

// AuthMiddleware checks if the user is authenticated
func AuthMiddlewares(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// Récupérer l'ID utilisateur depuis la session
		userID, err := authentification.GetSession(r)
		if err != nil {
			log.Println("Erreur: Session invalide:", err)
			http.Error(w, "Unauthorized: Session invalide", http.StatusUnauthorized)
			return
		}

		// Ajouter l'ID utilisateur au contexte de la requête
		ctx := context.WithValue(r.Context(), userIDKey, userID)
		next.ServeHTTP(w, r.WithContext(ctx))
	}
}

func SomeHandler(w http.ResponseWriter, r *http.Request) {
	userID, ok := r.Context().Value(userIDKey).(int) // ou le type attendu
	if !ok {
		http.Error(w, "Utilisateur non authentifié", http.StatusUnauthorized)
		return
	}

	// Utilisez userID comme nécessaire
	fmt.Fprintf(w, "Bonjour utilisateur %d", userID)
}

// GetUserProfile handles the request to retrieve user profile information
func GetUserProfile(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'ID utilisateur depuis la session
	userID, err := authentification.GetSession(r)
	if err != nil {
		log.Println("Erreur: Session invalide:", err)
		http.Error(w, "Vous devez être connecté pour accéder à cette page.", http.StatusUnauthorized)
		return
	}
	log.Printf("User ID récupéré depuis la session: %d", userID)

	// Récupérer le profil utilisateur
	userProfile, err := fetchUserProfile(userID)
	if err != nil {
		log.Printf("Erreur lors de la récupération du profil pour l'utilisateur %d: %v", userID, err)
		http.Error(w, "Nous n'avons pas pu récupérer vos informations. Veuillez réessayer plus tard.", http.StatusInternalServerError)
		return
	}
	log.Printf("Profil utilisateur récupéré: %+v", userProfile)

	// Récupérer les réservations
	reservations, err := fetchUserReservations(userID)
	if err != nil {
		log.Printf("Erreur lors de la récupération des réservations (ID: %d): %v", userID, err)
		http.Error(w, "Impossible de récupérer vos réservations pour le moment.", http.StatusInternalServerError)
		return
	}
	log.Printf("Réservations récupérées: %+v", reservations)

	// Préparer les données pour le template
	responseData := struct {
		User         *UserProfile
		Reservations []models.Reservation
	}{
		User:         userProfile,
		Reservations: reservations,
	}

	// Vérifier le type de requête
	acceptHeader := r.Header.Get("Accept")
	if strings.Contains(acceptHeader, "application/json") {
		// Réponse JSON pour les requêtes API
		w.Header().Set("Content-Type", "application/json")
		err = json.NewEncoder(w).Encode(responseData)
		if err != nil {
			log.Printf("Erreur lors de l'encodage de la réponse JSON: %v", err)
			http.Error(w, "Erreur lors de la préparation de la réponse", http.StatusInternalServerError)
		}
	} else {
		// Servir la page HTML pour les requêtes de navigateur
		tmpl, err := template.ParseFiles("./templates/profil.html")
		if err != nil {
			http.Error(w, fmt.Sprintf("Erreur lors de la récupération des détails de l'utilisateur: %v", err), http.StatusInternalServerError)
			return
		}
		err = tmpl.Execute(w, responseData)
		if err != nil {
			http.Error(w, fmt.Sprintf("Erreur lors de l'exécution du template: %v", err), http.StatusInternalServerError)
		}
	}
}

// UpdateUserProfile handles the request to update user profile information
func UpdateUserProfile(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'ID utilisateur depuis le contexte
	userID, ok := r.Context().Value("userID").(int)
	if !ok {
		http.Error(w, "Erreur lors de la récupération de l'ID utilisateur", http.StatusInternalServerError)
		return
	}

	// Récupérer les informations mises à jour depuis le formulaire
	firstName := r.FormValue("first_name")
	lastName := r.FormValue("last_name")
	email := r.FormValue("email")
	phoneNumber := r.FormValue("phone_number")
	address := r.FormValue("address")
	city := r.FormValue("city")
	country := r.FormValue("country")

	// Mettre à jour le profil de l'utilisateur dans la base de données
	err := updateUserProfile(userID, firstName, lastName, email, phoneNumber, address, city, country)
	if err != nil {
		http.Error(w, "Erreur lors de la mise à jour du profil", http.StatusInternalServerError)
		return
	}

	// Rediriger vers la page de profil mise à jour
	http.Redirect(w, r, "/profile", http.StatusSeeOther)
}

// UpdateUserReservation gère la mise à jour d'une réservation par l'utilisateur
func UpdateUserReservation(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'ID utilisateur depuis le contexte
	userID, ok := r.Context().Value(userIDKey).(int)
	if !ok {
		respondWithError(w, "Utilisateur non authentifié", http.StatusUnauthorized)
		return
	}

	// Décoder la requête JSON
	var updateReq UpdateReservationRequest
	if err := json.NewDecoder(r.Body).Decode(&updateReq); err != nil {
		respondWithError(w, "Format de requête invalide", http.StatusBadRequest)
		return
	}

	// Convertir les dates string en time.Time
	checkIn, err := time.Parse("2006-01-02", updateReq.CheckInDate)
	if err != nil {
		respondWithError(w, "Format de date d'arrivée invalide", http.StatusBadRequest)
		return
	}

	checkOut, err := time.Parse("2006-01-02", updateReq.CheckOutDate)
	if err != nil {
		respondWithError(w, "Format de date de départ invalide", http.StatusBadRequest)
		return
	}

	// Vérifier que la date de départ est après la date d'arrivée
	if checkOut.Before(checkIn) {
		respondWithError(w, "La date de départ doit être après la date d'arrivée", http.StatusBadRequest)
		return
	}

	// Vérifier que la réservation appartient à l'utilisateur
	belongs, err := verifyReservationOwnership(userID, updateReq.ReservationID)
	if err != nil {
		respondWithError(w, "Erreur lors de la vérification de la réservation", http.StatusInternalServerError)
		return
	}
	if !belongs {
		respondWithError(w, "Réservation non trouvée ou non autorisée", http.StatusForbidden)
		return
	}

	// Créer une instance de models.Reservation
	reservation := models.Reservation{
		ID:             updateReq.ReservationID,
		UserID:         userID,
		RoomID:         updateReq.RoomID,
		CheckInDate:    checkIn,
		CheckOutDate:   checkOut,
		NumberOfGuests: updateReq.NumberOfGuests,
		Status:         updateReq.Status,
	}

	// Créer un nouveau body avec la réservation
	var buf bytes.Buffer
	if err := json.NewEncoder(&buf).Encode(reservation); err != nil {
		respondWithError(w, "Erreur lors de l'encodage de la réservation", http.StatusInternalServerError)
		return
	}

	// Créer une nouvelle requête avec le nouveau body
	newReq, err := http.NewRequestWithContext(
		r.Context(),
		"PUT",
		r.URL.String(),
		&buf,
	)
	if err != nil {
		respondWithError(w, "Erreur lors de la création de la requête", http.StatusInternalServerError)
		return
	}
	newReq.Header = r.Header

	// Appeler UpdateReservation avec la nouvelle requête
	UpdateReservation(w, newReq)
}

// Fonction utilitaire pour vérifier que la réservation appartient à l'utilisateur
func verifyReservationOwnership(userID, reservationID int) (bool, error) {
	db := database.GetDB()
	var count int
	err := db.QueryRowContext(context.Background(),
		"SELECT COUNT(*) FROM reservations WHERE id = ? AND user_id = ?",
		reservationID, userID).Scan(&count)

	if err != nil {
		return false, err
	}
	return count > 0, nil
}

// Fonction utilitaire pour envoyer une réponse d'erreur JSON
func respondWithError(w http.ResponseWriter, message string, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(APIError{Error: message})
}

// CancelReservation handles the request to cancel a user's reservation
func CancelReservation(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'ID utilisateur depuis le contexte
	userID, ok := r.Context().Value("userID").(int)
	if !ok {
		http.Error(w, "Erreur lors de la récupération de l'ID utilisateur", http.StatusInternalServerError)
		return
	}

	// Retrieve reservation ID from the request
	reservationID, err := strconv.Atoi(r.URL.Query().Get("reservationId"))
	if err != nil {
		http.Error(w, "Invalid reservation ID", http.StatusBadRequest)
		return
	}

	// Cancel the reservation in the database
	err = cancelReservation(userID, reservationID)
	if err != nil {
		http.Error(w, "Erreur lors de l'annulation de la réservation", http.StatusInternalServerError)
		return
	}

	// Redirect the user back to the profile page
	http.Redirect(w, r, "/profile", http.StatusSeeOther)
}

// Helper functions to interact with the database
func fetchUserProfile(userID int) (*UserProfile, error) {
	db := database.GetDB()
	var user UserProfile

	err := db.QueryRowContext(context.Background(),
		"SELECT id, first_name, last_name, email, phone_number, address, city, country FROM users WHERE id = ?", userID).
		Scan(&user.ID, &user.FirstName, &user.LastName, &user.Email, &user.PhoneNumber, &user.Address, &user.City, &user.Country)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.New("utilisateur non trouvé")
		}
		return nil, err
	}

	return &user, nil
}

func fetchUserReservations(userID int) ([]models.Reservation, error) {
	db := database.GetDB()
	var reservations []models.Reservation

	rows, err := db.QueryContext(context.Background(),
		"SELECT r.id, r.check_in_date, r.check_out_date, rt.name AS room_type, r.status, r.payment_status, r.special_requests FROM reservations r JOIN room_types rt ON r.room_id = rt.id WHERE r.users_id = ? AND r.status != 'cancelled'", userID)
	if err != nil {
		log.Println("Erreur lors de la requête des réservations:", err)
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var reservation models.Reservation
		if err := rows.Scan(&reservation.ID, &reservation.CheckInDate, &reservation.CheckOutDate, &reservation.RoomType.Name, &reservation.Status, &reservation.PaymentStatus, &reservation.SpecialRequests); err != nil {
			log.Println("Erreur lors de la lecture des réservations:", err)
			return nil, err
		}
		reservations = append(reservations, reservation)
	}

	if err := rows.Err(); err != nil {
		log.Println("Erreur après l'itération des réservations:", err)
		return nil, err
	}

	return reservations, nil
}

func updateUserProfile(userID int, firstName, lastName, email, phoneNumber, address, city, country string) error {
	db := database.GetDB()

	_, err := db.ExecContext(context.Background(),
		"UPDATE users SET first_name = ?, last_name = ?, email = ?, phone_number = ?, address = ?, city = ?, country = ? WHERE id = ?",
		firstName, lastName, email, phoneNumber, address, city, country, userID)
	if err != nil {
		return err
	}

	return nil
}

func cancelReservation(userID, reservationID int) error {
	db := database.GetDB()

	_, err := db.ExecContext(context.Background(),
		"DELETE FROM reservations WHERE id = ? AND users_id = ?", reservationID, userID)
	if err != nil {
		return err
	}

	return nil
}

// renderUserProfilePage rend la page de profil utilisateur avec les données nécessaires
/*func renderUserProfilePage(w http.ResponseWriter, data struct {
	User         *UserProfile
	Reservations []models.Reservation
}) {
	// Charger le template HTML
	tmpl, err := template.ParseFiles(filepath.Join("templates", "profil.html"))
	if err != nil {
		log.Println("Erreur lors du chargement du template:", err)
		http.Error(w, "Erreur lors du chargement du template", http.StatusInternalServerError)
		return
	}

	// Exécuter le template avec les données
	err = tmpl.Execute(w, data)
	if err != nil {
		log.Println("Erreur lors de l'exécution du template:", err)
		http.Error(w, "Erreur lors de l'affichage de la page", http.StatusInternalServerError)
	}
}*/
